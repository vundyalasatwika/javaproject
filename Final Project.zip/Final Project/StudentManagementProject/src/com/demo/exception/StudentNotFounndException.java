package com.demo.exception;

public class StudentNotFounndException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StudentNotFounndException(String message) {
        super();
    }
}
