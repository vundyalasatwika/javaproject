package com.demo.exception;

public class DublicateData extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DublicateData(String message) {
        super();
    }
}
